# encoding: UTF-8
# Mauricio Medrano Castro, A01272273 
# Space Shooter Game 

from Graphics import *
from random import randint


v = Window("Shooter Game",800,600)
# Balas 
listaBalas = []
# Lista de enemigos
listaEnemigos= []


# Mi nave 
shooter = makePicture("shooter.png")
shooter.x = 400
shooter.y = 580
shooter.border = 0
#Texto para los puntos
txtPuntos = Text( (700,50), "Puntos : 0")
txtPuntos.color = Color("white")
puntosJugador = 0

# Inicio del juego 
juegoCorriendo = True

#Disparar al objetivo 
def dispararBalas() :
    for p in listaBalas :
        p.y -= 7
        if p.y <=0 :
            listaBalas.remove(p)
            v.undraw(p)


#Controles para mover a mi nave 
def atenderTeclado(v,e) :
    dis = 10
    if e.key == "Right" or e.key == "d" :
        shooter.x +=dis
    if e.key == "Left" or e.key == "a" : 
        shooter.x -=dis
    if e.key == "Up" or e.key == "w" :
        shooter.y -=dis
    if e.key == "Down" or e.key == "s" :
        shooter.y +=dis
    if e.key == "space" :
        #if para que el usuario solo pueda lanzar 3 proyectiles
        bullet = makePicture("bullet.png")
        bullet.y = shooter.y
        bullet.x = shooter.x
        bullet.border = 0
        bullet.draw(v)
        listaBalas.append(bullet)
        


#Moviendo a los enemigos hacia abajo 
def moverEnemigos1() :
    for enemigo in listaEnemigos :
        enemigo.y += 10
    
    
#Crea un enemigo, lo agrega a la pantalla y a la lista de enemigos
def crearEnemigo1() :
    enemigo = makePicture("enemigo1.png")
    enemigo.border = 0
    enemigo.x = randint(0,800)
    enemigo.y = randint(0, enemigo.height)
    enemigo.draw(v)
    listaEnemigos.append(enemigo)


# Aqui se verifica el impacto entre el enemigo y mi nave 
def verificarImpacto() :
    global puntosJugador
    
    for bala in listaBalas :
        for e in listaEnemigos : 
            ancho = e.width
            alto = e.height
            if bala.x >= e.x-ancho and bala.x <= e.x+ancho/2 :
                if bala.y >= e.y-alto/2 and bala.y <= e.y + alto/2 : 
                    puntosJugador += 10
                    txtPuntos.text = "Puntos: " + str(puntosJugador)
                    e.undraw()
                    listaEnemigos.remove(e)


def verificarColision() :  
    global juegoCorriendo 
    for e in listaEnemigos :
        ancho = e.width
        alto = e.height
        if shooter.x >= e.x - ancho/2 and shooter.x <= e.x + ancho/2 :
            if shooter.y >= e.y - ancho/2 and shooter.y <= e.y + ancho/2 :
                # pierde
                txtPierde = Text( (400,300), "Perdiste" )
                txtPierde.fontSize = 40
                txtPierde.color = Color("White")
                txtPierde.draw(v)
                juegoCorriendo = False



def main() :
          
    fondoA = makePicture("fondo.png")
    fondoA.border = 0
    fondoA.draw(v)
    
    
    # Mi nave dibujada 
    shooter.draw(v)
    #Teclado
    onKeyPress(atenderTeclado)
    #Acumulador de tiempo
    tiempo = 0
    LIMITE = .0041

    
    while True :
        v.step(0.034)
        
        if juegoCorriendo == True :
            tiempo += 0.034
            if tiempo >= LIMITE :
                tiempo = 0
                if LIMITE >= 0.3 :
                    LIMITE -= 0.01
                crearEnemigo1()
        
            dispararBalas()
            moverEnemigos1()
            verificarImpacto()
            txtPuntos.draw(v)
            verificarColision()
        
  
    
        


v.run(main)