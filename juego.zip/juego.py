#Encoding: UTF-8
#Pablo Sanchez Tadeo
#Super Flappy Bros
'''
El juego cuenta con 3 niveles, para avanzar al siguiente nivel se tienen que juntar 50 
puntos, los puntos se obtienen agarrando las monedas que aparecen, las cuales dan 5
puntos cada una.
El juego se maneja con las flechas o con las teclas wasd, son muchos toques ligeros en lugar
de dejar apretada la tecla, si choca con un tubo no pierde vidas, pero empujan al 
personaje hacia la izquierda y si se sale de la ventana pierde una vida. 
El jugador tiene 3 vidas, si pierde las 3 regresa al nivel 1 y pierde todos sus puntos.
Los puntos, niveles, puntos a llegar y vidas se guardan en un archivo, es decir, si el
usuario cierra el juego, este se guarda para continuar la siguiete vez que lo inicie.
'''
from Graphics import *
from random import randint
from Myro import play

def leerMarcador() :
    ent = open("marcador.txt","r")
    valor = ent.readline()
    
    puntos = int(valor)
    ent.close()
    return puntos
    
def leerNivel() :
    ent = open("marcador.txt","r")
    valor = ent.readline()
    nivel = ent.readline()
    nivel = int(nivel)
    ent.close()
    return nivel

def leerMetaPuntos() :
    ent = open("marcador.txt","r")
    valor = ent.readline()
    nivel = ent.readline()
    meta = ent.readline()
    meta = int(meta)
    ent.close()
    return meta
    
def leerVidas() :
    ent = open("marcador.txt","r")
    valor = ent.readline()
    nivel = ent.readline()
    meta = ent.readline()
    vidas = ent.readline()
    vidas = int(vidas)
    ent.close()
    return vidas

v = Window("Juego",800,600)

fondo = makePicture("background.png")
fondo.draw(v)

v.mode = "physics"
v.gravity = Vector(0,30)


per = makePicture("bird.png")
per.x = 400
per.y = 300

per.border = 0

continuar = Button( (370,25), "Continuar" )

btnIniciar = Button( (370,500), "Iniciar Juego" )
btnIniciar.draw(v)

listaObjetos = []
listaMonedas = []
disObjetos = 5
disMonedas = 4
LIMITE = 2
puntosJugador = leerMarcador()
puntuacion = Text( (100,50), "Tu puntuacion: " + str(puntosJugador) )
puntuacion.color = Color("black")
puntuacion.bodyType = "static"

metaPuntos = leerMetaPuntos()
nivel = leerNivel()

txtNivel = Text( (650,50), "Nivel: " + str(nivel) )
txtNivel.color = Color("black")
txtNivel.bodyType = "static"

txtCartel = Text( (400,300), "Felicidades, terminaste un nivel" )
txtCartel.color = Color("blue")
txtCartel.bodyType = "static"

vidas = leerVidas()

txtVidas = Text( (400,50), "Vidas: " + str(vidas))
txtVidas.color = Color("black")
txtVidas.bodyType = "static"



juegoCorriendo = True

juegoIniciado = "no"

def checarSalir(e,v) :
    salir = 0
    if e.key == "e" :
        salir = 1
    return salir

def atenderTeclado(v,e) :
    
    if e.key == "Up" or e.key == "w" :
        per.body.ApplyForce( Vector(0, -150) )
    if e.key == "Down" or e.key == "s" :
        per.body.ApplyForce( Vector(0, 150) )
    if e.key == "Left" or e.key == "a" :
        per.body.ApplyForce( Vector(-150,0) )
    if e.key == "Right" or e.key == "d" :
        #if per.x < 800 :
        per.body.ApplyForce( Vector(150,0) )    
    
        

def moverFondo(f) :
    f.x -= 5
    if f.x <= -400 :
        f.x = 1200

def crearObjetos() :
    
    num = randint(1,3)
    if num == 1 :
        obj = makePicture("pipe1.png")
        obj.border = 0
        obj.bodyType = "static"
        obj.x = 880
        obj.y = 535
        obj.draw(v)
        obj2 = makePicture("pipe2.png")
        obj2.border = 0
        obj2.bodyType = "static"
        obj2.x = 880
        obj2.y = 147
        obj2.draw(v)
        listaObjetos.append(obj)
        listaObjetos.append(obj2)
    elif num == 2 :
        obj3 = makePicture("pipe3.png")
        obj3.border = 0
        obj3.bodyType = "static"
        obj3.x = 880
        obj3.y = 65
        obj3.draw(v)
        obj4 = makePicture("pipe4.png")
        obj4.border = 0
        obj4.bodyType = "static"
        obj4.x = 880
        obj4.y = 452
        obj4.draw(v)
        listaObjetos.append(obj3)
        listaObjetos.append(obj4)
    elif num == 3 :
        obj5 = makePicture("pipe5.png")
        obj5.border = 0
        obj5.bodyType = "static"
        obj5.x = 880
        obj5.y = 55
        obj5.draw(v)
        obj6 = makePicture("pipe6.png")
        obj6.border = 0
        obj6.bodyType = "static"
        obj6.x = 880
        obj6.y = 542
        obj6.draw(v)
        listaObjetos.append(obj5)
        listaObjetos.append(obj6)
        
        
def crearMonedas() :
    coin = makePicture("coin.png")
    coin.border = 0
    coin.bodyType = "static"
    coin.x = 830
    coin.y = randint(150,450)
    coin.draw(v)
    listaMonedas.append(coin)
    
def moverObjetos() :
    for obj in listaObjetos :
        obj.x -= disObjetos
        if obj.x < -50 :
            listaObjetos.remove(obj)
            obj.undraw()
            
def moverMonedas() :
    for coins in listaMonedas :
        coins.x -= disMonedas
        if coins.x < -15 :
            listaMonedas.remove(coins)
            coins.undraw() 

def anadirPuntos() :
    global juegoCorriendo
    global puntosJugador 
    global metaPuntos  
    for coins in listaMonedas :
        ancho = coins.width
        alto = coins.height
        anchoPer = per.width
        altoPer = per.height
        
        if per.x+anchoPer/2 >= coins.x-ancho and per.x-anchoPer/2 <= coins.x+ancho :
            if per.y+altoPer/2 >= coins.y-alto and per.y-altoPer/2 <= coins.y+alto :
                coins.undraw()
                puntosJugador += 5
                puntuacion.text = "Tu puntuacion: " + str(puntosJugador)
                listaMonedas.remove(coins)
                play("coin.wav")
                
                if puntosJugador >= metaPuntos :
                    juegoCorriendo = False
                    botonContinuar()
                guardarMarcador()
                
                    
                
def reiniciarJuego() :
    global juegoCorriendo
    global LIMITE
    global vidas, puntosJugador
    juegoCorriendo = True
    per.x = 400
    per.y = 300
    for obj in listaObjetos:
        obj.undraw()
    for obj in listaObjetos :
        listaObjetos.remove(obj)
    for coin in listaMonedas :
        coin.undraw()
    for coins in listaMonedas :
        listaMonedas.remove(coins)
    if vidas == 0 :
        puntosJugador = 0
    puntuacion.text = "Tu puntuacion: " + str(puntosJugador)

        
def avanzarNivel(v,e) :
    global juegoCorriendo
    juegoCorriendo = True
    puntuacion.text = "Tu puntuacion: " + str(puntosJugador)
    txtCartel.undraw()
    continuar.Hide()
    reiniciarJuego()
                
def botonContinuar() :
    if nivel == 3 :
        txtCartel.text = "Felicidades, has terminado el juego"
    else :
        txtCartel.text = "Felicidades, terminasde un nivel"
    txtCartel.draw(v)
    continuar.draw(v)
    continuar.connect("click",avanzarNivel )
    
                   

def guardarMarcador() :
    ant = leerMarcador()
    if ant < puntosJugador or puntosJugador == 0 :
        s = open("marcador.txt","w")
        s.write( str(puntosJugador) + "\n" + str(nivel) + "\n" + str(metaPuntos) + "\n" + str(vidas))
        s.close()
    
def iniciarJuego(btn,e) :
    global juegoIniciado
    juegoIniciado = "si"
    
def verNivel() :
    global LIMITE, nivel
    global disObjetos, disMonedas, metaPuntos, puntosJugador
    if puntosJugador < 50 :
        nivel = 1
        metaPuntos = 50
        LIMITE = 2
        disObjetos = 5
        disMonedas = 4
    if puntosJugador >= 50 and puntosJugador < 100 :
        nivel = 2
        metaPuntos = 100
        LIMITE = 1
        disObjetos = 10
        disMonedas = 7
    if puntosJugador >= 100 and puntosJugador < 150 :
        nivel = 3
        metaPuntos = 150
        LIMITE = 0.5
        disObjetos = 15
        disMonedas = 13
    if puntosJugador >= 150 :
        nivel = 1
        metaPuntos= 50
        puntosJugador = 0
        LIMITE = 2
        disObjetos = 5
        disMonedas = 4
    guardarMarcador()
    txtNivel.text = "Nivel: " + str(nivel)

def main() :
    global vidas
    global juegoCorriendo
    p = Rectangle( (0,0), (800,1) )
    p.bodyType = "static"
    p.draw(v)
    p = Rectangle( (0,600), (800,601) )
    p.bodyType = "static"
    p.draw(v)
    fondoA = makePicture("background.png")
    fondoA.border = 0
    fondoA.bodyType = "static"
    fondoA.draw(v)
    fondoB = makePicture("background.png")
    fondoB.x = 1200
    fondoB.bodyType = "static"
    fondoB.border = 0
    fondoB.draw(v)
    
    onKeyPress(atenderTeclado)
    
 
    tiempo = 0
    
    btnIniciar.connect("click",iniciarJuego)
    logo = makePicture("flappy.png")
    logo.x = 400
    logo.y = 300
    logo.bodyType = "static"
    logo.border = 0
    logo.draw(v)
    while juegoIniciado != "si" :
        v.step(0.034)
        moverFondo(fondoA)
        moverFondo(fondoB)
    logo.undraw()
    btnIniciar.Hide()
    per.draw(v)
    fondoA.undraw()
    fondoB.undraw()
    while True :
        v.step(0.034)
        verNivel()
        if juegoCorriendo == True :
            tiempo += 0.034
            if tiempo >= LIMITE :
                tiempo = 0
                crearObjetos()
                crearMonedas()
            moverObjetos()
            moverMonedas()
            anadirPuntos()
            txtNivel.draw(v)
            puntuacion.draw(v)
            if per.x >= 768 :
                per.x = 768
            if per.x < 0 :
                vidas -= 1
                juegoCorriendo = False
                reiniciarJuego()
                if vidas == 0 :
                    juegoCorriendo = False
                    reiniciarJuego()
                    vidas = 3
                txtVidas.text = "Vidas: " + str(vidas)
            txtVidas.draw(v)
 

v.run(main)