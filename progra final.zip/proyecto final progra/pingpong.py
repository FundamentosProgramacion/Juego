#encoding: UTF-8
#Autor: Astrid Villegas
#Ping Pong

from Graphics import *
from random import randint

v = Window ( "PingPong", 800, 600)
fondo = makePicture("espiralNivelUno.jpg")
fondo.border = 0
fondo.draw (v)
v.mode = "physics"
v.gravity = Vector (0, 10.81)

#Variables globales


plataforma = Rectangle( (300,570), (500,590))
plataforma.bodyType = "static"
plataforma.rotation = 3
#plataforma.draw (v)

balin = Circle ((450,400),10)
balin.bounce = 1.5
balin.draw (v)
listaLadrillos = []

juegoCorriendo = True

def atenderTeclado (v, e):    
          
    if e.key == "Right":
        plataforma.x += 10
    if e.key == "Left":
        plataforma.x -= 10
        
#def moverPlataforma (v):

def crearLadrillos (v):
    n = 0
    x = 50
    #y = 50
    for k in range (3):
        while n <= 4:
            y = 50
            ladrillo = makePicture ("ladrillo.jpg")
            ladrillo.border = 0
            ladrillo.bodyType = "static"
            ladrillo.x = x + ladrillo.width
            ladrillo.y = y + ladrillo.height
            ladrillo.draw (v)
            listaLadrillos.append(ladrillo)
            for k in range (3):
                y = y + 70
                ladrillo = makePicture ("ladrillo.jpg")
                ladrillo.border = 0
                ladrillo.bodyType = "static"
                ladrillo.x = x + ladrillo.width
                ladrillo.y = y + ladrillo.height
                ladrillo.draw (v)
                listaLadrillos.append(ladrillo)
                
            x = x + 130
                          
            n = n+1
            
def verificarChoque (v):
    for l in listaLadrillos:
        ancho = l.width
        alto = l.height
        #if balin.x >= l.x - ancho/2 and balin.x <= l.x + ancho/2:
        if balin.y >= l.y-11-ancho/2 and balin.y <= l.y+11+ancho/2:
            if balin.x >= l.x-11-ancho/2 and balin.x <= l.x+11+ancho/2:
                #Chocooo!!!
                #puntosJugador += 10
                #textoP.text = "Puntos: " + str (puntosJugador)
                l.undraw()
                listaLadrillos.remove (l)
                
                
def dibujarMarco() :
    izq = Rectangle( (0,0), (10,600) )
    izq.color = Color("white")
    izq.bodyType = "static"
    izq.draw(v)
    
    arriba = Rectangle( (0,0), (800,10) )
    arriba.color = Color("white")
    arriba.bodyType = "static"
    arriba.bounce = -3
    arriba.friction = 0.01
    arriba.draw(v)

    der = Rectangle( (780,0), (800,600) )
    der.color = Color("white")
    der.bodyType = "static"
    der.draw(v)
    

def main ():
    
    dibujarMarco()
    #balin = Circle ((500,400),10)
     
    plataforma.draw(v)
    
    onKeyPress (atenderTeclado)
    
    crearLadrillos (v)
    #crearProyectil (v)
    #balin = Circle ((500,400),10)
    #balin.draw (v)
    
    verificarChoque (v)
        
    while True:
        v.step (0.034)
        verificarChoque (v)
        plataforma.rotation = plataforma.rotation+0.003

v.run (main)